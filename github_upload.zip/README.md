# HIV-1 subtype C drug resistance in Southern Africa: analysis scripts

Python scripts used in the thesis (Appendix E).

| Script | Purpose |
|---|---|
| `compile_metadata_dedup.py` (Code E1) | Compiles sequence metadata, de-duplicates by accession or patient identifier, and excludes sequences with more than 5% ambiguous bases |
| `fostemsavir_gp120_screen.py` (Code E2) | Screens fostemsavir resistance-associated polymorphisms in HIV-1 gp120 (HXB2 numbering) |

## Install
```
pip install -r requirements.txt
```

## Usage
```
python compile_metadata_dedup.py --indir "path/to/FASTAFILES" --region RT
python fostemsavir_gp120_screen.py --ref HXB2_gp160.fasta --indir "path/to/APOBEC_ADJUSTED_FASTAS"
```
Input file names follow `<COUNTRY>DRUG<NAIVE|EXPERIENCED>.txt` (E1) and `adjusted_<COUNTRY>DRUG<NAIVE|EXPERIENCED>.fasta` (E2).
Default folders in the scripts are Windows paths from the author's computer; change them with `--indir`.

## Data
Sequences are public (GenBank / Los Alamos HIV database). Sequence data are not included in this repository.
