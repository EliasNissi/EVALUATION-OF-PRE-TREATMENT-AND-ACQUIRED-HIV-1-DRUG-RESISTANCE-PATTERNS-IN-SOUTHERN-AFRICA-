import argparse
import csv
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

from Bio import SeqIO

DEFAULT_INDIR = r"C:\Users\admin\Downloads\gg\FASTAFILESW"

COUNTRY_NAMES = {
    "BOTSWANA": "Botswana", "MALAWI": "Malawi", "MOZAMBIQUE": "Mozambique",
    "SOUTHAFRICA": "South Africa", "ZAMBIA": "Zambia", "ZIMBABWE": "Zimbabwe",
    "ZIMBAWE": "Zimbabwe",  # spelling used in one of the file names
}
STATUS_NAMES = {"NAIVE": "ART-naive", "EXPERIENCED": "ART-experienced"}

LANL_YEAR = re.compile(r"^(19[5-9]\d|20[0-4]\d)$")
ACC = re.compile(r"(?<![A-Za-z0-9])([A-Z]{1,2}_?\d{5,8})(?:\.\d+)?(?![A-Za-z0-9])")
YEAR = re.compile(r"(?<!\d)(19[89]\d|20[0-4]\d)(?!\d)")
FILE_RE = re.compile(r"^(.+?)DRUG(NAIVE|EXPERIENCED)$", re.I)


def parse_file_label(path):
    m = FILE_RE.match(Path(path).stem.upper())
    if not m:
        return None
    return COUNTRY_NAMES.get(m.group(1), m.group(1).title()), STATUS_NAMES[m.group(2).upper()]


def parse_header(header, custom=None):
    """Return dict(accession, year, patient_id, id_source)."""
    if custom is not None:
        m = custom.search(header)
        gd = m.groupdict() if m else {}
        return {"accession": (gd.get("acc") or "").upper(), "year": gd.get("year") or "",
                "patient_id": gd.get("pid") or "", "id_source": "custom regex"}
    first = header.split()[0] if header.split() else ""
    parts = first.split(".")
    if len(parts) >= 5 and LANL_YEAR.match(parts[2]):
        return {"accession": parts[-1].upper(), "year": parts[2],
                "patient_id": ".".join(parts[3:-1]), "id_source": "LANL header"}
    m = ACC.search(first)
    ym = YEAR.search(header)
    return {"accession": (m.group(1).upper() if m else first.upper()),
            "year": ym.group(1) if ym else "", "patient_id": "",
            "id_source": "GenBank-like token" if m else "first word of header"}


def base_counts(seq):
    s = re.sub(r"[^A-Za-z]", "", str(seq)).upper().replace("U", "T")
    unamb = sum(s.count(b) for b in "ACGT")
    return len(s), unamb, len(s) - unamb


def components(recs):
    """Group records that share an accession or a (country, patient ID); returns group labels."""
    parent = list(range(len(recs)))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    first = {}
    for i, r in enumerate(recs):
        keys = []
        if r["accession"]:
            keys.append(("acc", r["accession"]))
        if r["patient_id"]:
            keys.append(("pid", r["country"], r["patient_id"]))
        for k in keys:
            if k in first:
                ra, rb = find(i), find(first[k])
                if ra != rb:
                    parent[rb] = ra
            else:
                first[k] = i
    return [find(i) for i in range(len(recs))]


def better(a, b):
    """True if record a has better coverage than b."""
    return (a["unambiguous_bases"], -a["ambiguous_bases"], -a["_order"]) > \
           (b["unambiguous_bases"], -b["ambiguous_bases"], -b["_order"])


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--indir", default=DEFAULT_INDIR)
    ap.add_argument("--outdir", default=None, help="default: <indir>\\CLEANED")
    ap.add_argument("--region", default="NA", help="sequence region label, e.g. RT, PR, IN, env")
    ap.add_argument("--max-ambig", type=float, default=0.05, help="exclude sequences with a larger fraction")
    ap.add_argument("--scope", choices=["file", "global"], default="file",
                    help="de-duplicate within each file (default) or across all files")
    ap.add_argument("--header-regex", default=None, help="regex with named groups acc, year, pid")
    args = ap.parse_args()

    indir = Path(args.indir)
    outdir = Path(args.outdir) if args.outdir else indir / "CLEANED"
    outdir.mkdir(parents=True, exist_ok=True)
    custom = re.compile(args.header_regex) if args.header_regex else None

    files = [f for f in sorted(indir.glob("*.txt")) if parse_file_label(f)]
    if not files:
        sys.exit(f"No <COUNTRY>DRUG<NAIVE|EXPERIENCED>.txt files found in {indir}")

    # ---- 1-2. read sequences and build metadata --------------------------------------
    recs, order = [], 0
    for f in files:
        country, art = parse_file_label(f)
        for rec in SeqIO.parse(f, "fasta"):
            h = parse_header(rec.description, custom)
            n, unamb, amb = base_counts(rec.seq)
            recs.append({"accession": h["accession"], "patient_id": h["patient_id"], "country": country,
                         "sampling_year": h["year"], "sequence_region": args.region, "ART_status": art,
                         "source_file": f.name, "id_source": h["id_source"], "header": rec.description,
                         "length": n, "unambiguous_bases": unamb, "ambiguous_bases": amb,
                         "ambiguous_pct": round(100.0 * amb / n, 2) if n else 100.0,
                         "duplicate_group": "", "status": "", "reason": "",
                         "_record": rec, "_order": order})
            order += 1

    # ---- 3. de-duplicate ---------------------------------------------------------------
    scopes = defaultdict(list)
    for i, r in enumerate(recs):
        scopes[r["source_file"] if args.scope == "file" else "ALL"].append(i)
    gid = 0
    for idxs in scopes.values():
        labels = components([recs[i] for i in idxs])
        by_label = defaultdict(list)
        for i, lab in zip(idxs, labels):
            by_label[lab].append(i)
        for members in by_label.values():
            gid += 1
            best = members[0]
            for i in members[1:]:
                if better(recs[i], recs[best]):
                    best = i
            for i in members:
                recs[i]["duplicate_group"] = f"G{gid}" if len(members) > 1 else ""
                if i == best:
                    recs[i]["status"] = "kept"
                else:
                    recs[i]["status"] = "removed_duplicate"
                    recs[i]["reason"] = f"same accession/patient as {recs[best]['accession']}; lower coverage"

    # ---- 4. ambiguity filter on the de-duplicated set -----------------------------------
    for r in recs:
        if r["status"] == "kept" and (r["length"] == 0 or r["ambiguous_bases"] / r["length"] > args.max_ambig):
            r["status"] = "excluded_ambiguity"
            r["reason"] = f">{args.max_ambig * 100:g}% ambiguous bases ({r['ambiguous_pct']}%)"

    # warn if the same individual appears in several files while scope=file
    cross = 0
    if args.scope == "file":
        kept = [r for r in recs if r["status"] == "kept"]
        accs = defaultdict(set)
        for r in kept:
            if r["accession"]:
                accs[r["accession"]].add(r["source_file"])
        cross = sum(len(v) > 1 for v in accs.values())

    # ---- 5. outputs ---------------------------------------------------------------------
    for f in files:
        keep = [r["_record"] for r in recs if r["source_file"] == f.name and r["status"] == "kept"]
        SeqIO.write(keep, outdir / f"{f.stem}_dedup_filtered.fasta", "fasta")

    cols = ["accession", "patient_id", "country", "sampling_year", "sequence_region", "ART_status",
            "source_file", "id_source", "length", "unambiguous_bases", "ambiguous_bases", "ambiguous_pct",
            "duplicate_group", "status", "reason", "header"]
    final = [r for r in recs if r["status"] == "kept"]

    summary = []
    for f in files:
        rs = [r for r in recs if r["source_file"] == f.name]
        c = Counter(r["status"] for r in rs)
        summary.append({"source_file": f.name, "country": rs[0]["country"] if rs else "",
                        "ART_status": rs[0]["ART_status"] if rs else "", "sequences_in": len(rs),
                        "duplicates_removed": c["removed_duplicate"],
                        "excluded_ambiguity": c["excluded_ambiguity"], "final": c["kept"],
                        "missing_year_in_final": sum(1 for r in rs if r["status"] == "kept" and not r["sampling_year"])})
    tot = {k: sum(s[k] for s in summary) for k in
           ["sequences_in", "duplicates_removed", "excluded_ambiguity", "final", "missing_year_in_final"]}
    summary.append({"source_file": "TOTAL", "country": "", "ART_status": "", **tot})
    scols = ["source_file", "country", "ART_status", "sequences_in", "duplicates_removed",
             "excluded_ambiguity", "final", "missing_year_in_final"]

    def dump_csv(name, rows, fields):
        with open(outdir / name, "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
            w.writeheader()
            w.writerows(rows)

    dump_csv("metadata_all_sequences.csv", recs, cols)
    dump_csv("metadata_final.csv", final, cols)
    dump_csv("summary_counts.csv", summary, scols)
    try:
        from openpyxl import Workbook
        wb = Workbook()
        wb.remove(wb.active)
        for title, rows, fields in [("Metadata_final", final, cols), ("Metadata_all", recs, cols),
                                    ("Summary", summary, scols)]:
            ws = wb.create_sheet(title)
            ws.append(fields)
            for r in rows:
                ws.append([r.get(k, "") for k in fields])
        wb.save(outdir / "metadata_table.xlsx")
    except ImportError:
        print("openpyxl not installed: wrote CSV files only.")

    print(f"{'file':45s} {'in':>7s} {'dup':>6s} {'ambig':>6s} {'final':>7s}")
    for s in summary:
        print(f"{s['source_file']:45s} {s['sequences_in']:7d} {s['duplicates_removed']:6d} "
              f"{s['excluded_ambiguity']:6d} {s['final']:7d}")
    if cross:
        print(f"\nNOTE: {cross} accession(s) kept in more than one file; use --scope global "
              f"if each individual must appear only once across all files.")
    noparse = sum(1 for r in final if r["id_source"] == "first word of header")
    if noparse:
        print(f"NOTE: {noparse} final sequences had no GenBank-like accession; the first word of the "
              f"header was used as the ID. Check the header format or pass --header-regex.")
    print(f"\nResults written to {outdir}")


if __name__ == "__main__":
    main()
