import argparse
import csv
import itertools
import math
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

from Bio import SeqIO
from Bio.Align import PairwiseAligner, substitution_matrices
from Bio.Data import CodonTable
from Bio.Seq import Seq

DEFAULT_INDIR = r"C:\Users\admin\Downloads\gg\FASTAFILESW\SOUTHERN AFRICA SUBTYPE C\APOBEC_ADJUSTED_FASTAS"

# --------------------------------------------------------------------------------------
# Sites of interest: position -> (HXB2 wild-type aa, {substituted aa: category})
# --------------------------------------------------------------------------------------
SITES = {
    116: ("L", {"P": "additional", "Q": "additional"}),
    202: ("T", {"E": "primary"}),
    204: ("A", {"D": "additional"}),
    375: ("S", {aa: "primary" for aa in "HIMNTY"}),
    426: ("M", {"L": "primary", "P": "primary"}),
    434: ("M", {"I": "primary", "K": "primary"}),
    475: ("M", {"I": "primary"}),
    506: ("V", {"M": "additional"}),
}

COUNTRY_NAMES = {
    "BOTSWANA": "Botswana",
    "MALAWI": "Malawi",
    "MOZAMBIQUE": "Mozambique",
    "SOUTHAFRICA": "South Africa",
    "ZAMBIA": "Zambia",
    "ZIMBABWE": "Zimbabwe",
    "ZIMBAWE": "Zimbabwe",  # spelling used in one of the file names
}
STATUS_NAMES = {"NAIVE": "Drug-naive", "EXPERIENCED": "Drug-experienced"}

# --------------------------------------------------------------------------------------
# Translation with IUPAC ambiguity handling
# --------------------------------------------------------------------------------------
IUPAC = {
    "A": "A", "C": "C", "G": "G", "T": "T", "U": "T",
    "R": "AG", "Y": "CT", "S": "CG", "W": "AT", "K": "GT", "M": "AC",
    "B": "CGT", "D": "AGT", "H": "ACT", "V": "ACG",
}  # N is deliberately absent: codons containing N are treated as masked/unresolved
FWD = CodonTable.unambiguous_dna_by_id[1].forward_table
STOPS = {"TAA", "TAG", "TGA"}


def codon_options(codon):
    """Set of amino acids a codon can encode; {'X'} if masked (N), unresolved, or gapped."""
    codon = codon.upper()
    if len(codon) < 3 or any(c not in IUPAC for c in codon):
        return frozenset({"X"})
    out = set()
    for combo in itertools.product(*(IUPAC[c] for c in codon)):
        cod = "".join(combo)
        out.add("*" if cod in STOPS else FWD[cod])
    return frozenset(out)


def clean_nt(seq):
    return re.sub(r"[^A-Za-z]", "", str(seq)).upper()


def is_nucleotide(seq):
    s = set(clean_nt(seq))
    return len(s) > 0 and s <= set("ACGTUNRYSWKMBDHV")


def translate_frame(nt, frame):
    codons = [nt[i:i + 3] for i in range(frame, len(nt) - 2, 3)]
    opts = [codon_options(c) for c in codons]
    aa = "".join(next(iter(o)) if len(o) == 1 else "X" for o in opts)
    return aa, opts


# --------------------------------------------------------------------------------------
# Alignment to HXB2
# --------------------------------------------------------------------------------------
def make_aligner():
    al = PairwiseAligner()
    al.substitution_matrix = substitution_matrices.load("BLOSUM62")
    al.mode = "global"
    al.open_gap_score = -10.0
    al.extend_gap_score = -0.5
    al.end_gap_score = 0.0          # free end gaps: partial sequences are allowed on either end
    return al


def load_reference(path):
    rec = next(SeqIO.parse(path, "fasta"))
    seq = clean_nt(rec.seq) if is_nucleotide(rec.seq) else re.sub(r"[^A-Za-z*]", "", str(rec.seq)).upper()
    if is_nucleotide(rec.seq):
        i = seq.find("ATG")
        seq = str(Seq(seq[i:]).translate(to_stop=True))
    else:
        seq = seq.replace("*", "")
    problems = []
    for pos, (wt, _) in SITES.items():
        got = seq[pos - 1] if pos <= len(seq) else "?"
        if got != wt:
            problems.append(f"position {pos}: expected {wt}, reference has {got}")
    if problems:
        print("WARNING: reference does not look like HXB2 gp160 at: " + "; ".join(problems), file=sys.stderr)
        print("         Check that --ref is HXB2 Env with standard numbering.", file=sys.stderr)
    return seq


def map_sequence(ref, rec_seq, aligner):
    """Return (position -> set of aa options, qc dict). Positions are 1-based HXB2 numbering."""
    if is_nucleotide(rec_seq):
        nt = clean_nt(rec_seq)
        best = None
        for frame in range(3):
            aa, opts = translate_frame(nt, frame)
            if len(aa) < 30:
                continue
            score = aligner.score(ref, aa)
            if best is None or score > best[0]:
                best = (score, frame, aa, opts)
        if best is None:
            return {}, {"frame": "NA", "score": 0, "aligned": 0, "identity": 0.0}
        score, frame, aa, opts = best
    else:
        aa = re.sub(r"[^A-Za-z*]", "", str(rec_seq)).upper()
        opts = [frozenset({c}) for c in aa]
        frame, score = "protein", aligner.score(ref, aa)

    aln = aligner.align(ref, aa)[0]
    tblocks, qblocks = aln.aligned
    pos_opts, matches, aligned = {}, 0, 0
    for (t0, t1), (q0, q1) in zip(tblocks, qblocks):
        for k in range(t1 - t0):
            rpos, qidx = t0 + k + 1, q0 + k
            pos_opts[rpos] = opts[qidx]
            aligned += 1
            matches += ref[t0 + k] == aa[qidx]
    qc = {"frame": frame, "score": round(score, 1), "aligned": aligned,
          "identity": round(100.0 * matches / aligned, 1) if aligned else 0.0}
    return pos_opts, qc


# --------------------------------------------------------------------------------------
# Site calling
# --------------------------------------------------------------------------------------
def call_site(pos, options):
    """Return (status, observed_string, mutation_label, category, ram_possible)."""
    wt, ram = SITES[pos]
    if options is None or options == frozenset({"X"}):
        return "MISSING", "", "", "", False
    if len(options) == 1:
        aa = next(iter(options))
        if aa == wt:
            return "WT", aa, "", "", False
        if aa in ram:
            return "RAM", aa, f"{wt}{pos}{aa}", ram[aa], False
        return "OTHER", aa, f"{wt}{pos}{aa}", "", False
    obs = "/".join(sorted(options))
    return "MIXED", obs, "", "", bool(set(options) & set(ram))


def wilson(k, n, z=1.96):
    if n == 0:
        return float("nan"), float("nan")
    p = k / n
    d = 1 + z * z / n
    c = p + z * z / (2 * n)
    a = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return (c - a) / d, (c + a) / d


def parse_label(path):
    stem = re.sub(r"^adjusted_", "", Path(path).stem, flags=re.I).upper()
    m = re.match(r"^(.+?)(?:DRUG)?(NAIVE|EXPERIENCED)$", stem)
    if not m:
        return stem.title(), "Unknown"
    country = COUNTRY_NAMES.get(m.group(1), m.group(1).title())
    return country, STATUS_NAMES[m.group(2)]


# --------------------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--ref", required=True, help="HXB2 gp160 protein (or env CDS) FASTA")
    ap.add_argument("--indir", default=DEFAULT_INDIR)
    ap.add_argument("--outdir", default=None)
    ap.add_argument("--min-identity", type=float, default=60.0,
                    help="flag sequences whose aligned identity to HXB2 is below this (percent)")
    args = ap.parse_args()

    indir = Path(args.indir)
    outdir = Path(args.outdir) if args.outdir else indir / "FTR_results"
    outdir.mkdir(parents=True, exist_ok=True)
    files = sorted(indir.glob("adjusted_*.fasta"))
    if not files:
        sys.exit(f"No adjusted_*.fasta files found in {indir}")

    ref = load_reference(args.ref)
    aligner = make_aligner()

    site_rows, qc_rows = [], []
    agg = defaultdict(lambda: {"seqs": 0, "cov": 0, "WT": 0, "OTHER": 0, "MIXED": 0, "MIXED_RAM": 0,
                               "RAM": Counter(), "spectrum": Counter()})
    grp_tot = defaultdict(lambda: {"seqs": 0, "primary": 0, "any": 0, "qc_fail": 0})

    for f in files:
        country, status = parse_label(f)
        gkey = (country, status)
        print(f"{f.name}: {country} / {status}")
        for rec in SeqIO.parse(f, "fasta"):
            pos_opts, qc = map_sequence(ref, rec.seq, aligner)
            low_id = qc["identity"] < args.min_identity
            qc_rows.append({"file": f.name, "country": country, "treatment_status": status,
                            "sequence_id": rec.id, **qc, "low_identity_flag": int(low_id)})
            grp_tot[gkey]["seqs"] += 1
            grp_tot[gkey]["qc_fail"] += int(low_id)
            has_primary = has_any = False
            for pos in sorted(SITES):
                st, obs, label, cat, ram_poss = call_site(pos, pos_opts.get(pos))
                site_rows.append({"file": f.name, "country": country, "treatment_status": status,
                                  "sequence_id": rec.id, "position": pos, "hxb2_aa": SITES[pos][0],
                                  "observed": obs, "call": st, "mutation": label, "category": cat,
                                  "mixture_includes_RAM": int(ram_poss)})
                a = agg[(country, status, pos)]
                a["seqs"] += 1
                if st == "MISSING":
                    continue
                a["cov"] += 1
                a["spectrum"][obs] += 1
                if st == "RAM":
                    a["RAM"][label] += 1
                    has_any = True
                    has_primary |= cat == "primary"
                elif st in ("WT", "OTHER", "MIXED"):
                    a[st] += 1
                    a["MIXED_RAM"] += int(ram_poss and st == "MIXED")
            grp_tot[gkey]["primary"] += has_primary
            grp_tot[gkey]["any"] += has_any

    def write_csv(name, rows, fields):
        with open(outdir / name, "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=fields)
            w.writeheader()
            w.writerows(rows)

    # per-sequence site calls and QC
    write_csv("A_per_sequence_site_calls.csv", site_rows,
              ["file", "country", "treatment_status", "sequence_id", "position", "hxb2_aa", "observed",
               "call", "mutation", "category", "mixture_includes_RAM"])
    write_csv("A_sequence_QC.csv", qc_rows,
              ["file", "country", "treatment_status", "sequence_id", "frame", "score", "aligned",
               "identity", "low_identity_flag"])

    # per country x status x site summary
    summ = []
    for (country, status, pos), a in sorted(agg.items()):
        wt = SITES[pos][0]
        n_ram = sum(a["RAM"].values())
        lo, hi = wilson(n_ram, a["cov"])
        spectrum = "; ".join(f"{aa}:{n}" for aa, n in sorted(a["spectrum"].items(), key=lambda x: -x[1]))
        muts = "; ".join(f"{m}:{n}" for m, n in sorted(a["RAM"].items(), key=lambda x: -x[1]))
        summ.append({"country": country, "treatment_status": status, "position": pos, "hxb2_aa": wt,
                     "n_sequences": a["seqs"], "n_covered": a["cov"], "n_WT": a["WT"], "n_RAM": n_ram,
                     "RAM_breakdown": muts, "n_other_substitution": a["OTHER"], "n_mixed": a["MIXED"],
                     "n_mixed_including_RAM": a["MIXED_RAM"],
                     "RAM_prevalence_pct": round(100 * n_ram / a["cov"], 2) if a["cov"] else "",
                     "CI95_low_pct": round(100 * lo, 2) if a["cov"] else "",
                     "CI95_high_pct": round(100 * hi, 2) if a["cov"] else "",
                     "aa_spectrum": spectrum})
    write_csv("B_summary_by_country_status_site.csv", summ,
              ["country", "treatment_status", "position", "hxb2_aa", "n_sequences", "n_covered", "n_WT",
               "n_RAM", "RAM_breakdown", "n_other_substitution", "n_mixed", "n_mixed_including_RAM",
               "RAM_prevalence_pct", "CI95_low_pct", "CI95_high_pct", "aa_spectrum"])

    # per country x status: sequences carrying >=1 RAM
    tot = []
    for (country, status), t in sorted(grp_tot.items()):
        n = t["seqs"]
        lo, hi = wilson(t["primary"], n)
        tot.append({"country": country, "treatment_status": status, "n_sequences": n,
                    "n_with_primary_RAM": t["primary"],
                    "primary_RAM_pct": round(100 * t["primary"] / n, 2) if n else "",
                    "CI95_low_pct": round(100 * lo, 2) if n else "",
                    "CI95_high_pct": round(100 * hi, 2) if n else "",
                    "n_with_any_RAM_incl_additional": t["any"],
                    "n_low_identity_flag": t["qc_fail"]})
    write_csv("C_summary_by_country_status.csv", tot,
              ["country", "treatment_status", "n_sequences", "n_with_primary_RAM", "primary_RAM_pct",
               "CI95_low_pct", "CI95_high_pct", "n_with_any_RAM_incl_additional", "n_low_identity_flag"])

    # optional workbook
    try:
        from openpyxl import Workbook
        wb = Workbook()
        wb.remove(wb.active)
        for name, label in [("C_summary_by_country_status.csv", "TableA1_by_group"),
                            ("B_summary_by_country_status_site.csv", "TableA2_by_site"),
                            ("A_sequence_QC.csv", "SequenceQC")]:
            ws = wb.create_sheet(label)
            with open(outdir / name, encoding="utf-8") as fh:
                for row in csv.reader(fh):
                    ws.append([float(x) if re.fullmatch(r"-?\d+(\.\d+)?", x) else x for x in row])
        wb.save(outdir / "FTR_summary_tables.xlsx")
    except ImportError:
        print("openpyxl not installed: skipped .xlsx (CSV outputs are complete).")

    print(f"\nDone. Results written to {outdir}")
    flagged = sum(r["low_identity_flag"] for r in qc_rows)
    if flagged:
        print(f"NOTE: {flagged} sequences have <{args.min_identity}% identity to the reference "
              f"(see A_sequence_QC.csv); check frame/orientation or reference.")


if __name__ == "__main__":
    main()
